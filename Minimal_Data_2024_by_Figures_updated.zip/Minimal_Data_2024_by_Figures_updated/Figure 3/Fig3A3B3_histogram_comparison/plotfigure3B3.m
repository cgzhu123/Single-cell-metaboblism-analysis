clc;
clear all;

data=[14.8	4.3
16	10
5	40.9
2.9	24
3.2	40
2.8	14.6
34	28.8
6.3	29.1
-6.6	74.8
22.1	30
    ];

t=[1 2];

figure (1)
plot(t, data(1,:), 'b','MarkerSize',10,'Marker','x','LineWidth',1,'LineStyle','-');
hold on
plot(t, data(2,:), 'g','MarkerSize',10,'Marker','x','LineWidth',1,'LineStyle','-');
hold on
plot(t, data(3,:), 'b','MarkerSize',10,'Marker','pentagram','LineWidth',1,'LineStyle','-.');
hold on
plot(t, data(4,:), 'g','MarkerSize',10,'Marker','pentagram','LineWidth',1,'LineStyle','-.');
hold on
plot(t, data(5,:), 'b','MarkerSize',10,'Marker','diamond','LineWidth',1,'LineStyle',':');
hold on
plot(t, data(6,:), 'g','MarkerSize',10,'Marker','diamond','LineWidth',1,'LineStyle',':');
hold on
plot(t, data(7,:), 'b','MarkerSize',10,'Marker','square','LineWidth',1,'LineStyle','--');
hold on
plot(t, data(8,:), 'g','MarkerSize',10,'Marker','square','LineWidth',1,'LineStyle','--');
hold on
plot(t, data(9,:),'b','MarkerSize',10,'Marker','o','LineWidth',1,'LineStyle','-');
hold on
plot(t, data(10,:), 'g','MarkerSize',10,'Marker','o','LineWidth',1,'LineStyle','-');
hold on

axis([0.9,2.1,-60,100]);

title ('Histogram comparison','FontSize',20,'FontName','times new roman');
ylabel('Relative change (%)');

set(gca,'FontName','Times New Roman','FontSize',20,'XTick',[1 2],...
    'XTickLabel',{'Microscopy','Flowcytometry '},'YTick',...
    [-100 -75 -50 -25 0 25 50 75 100 ]);
set(gcf, 'Position', [0, 0, 550, 450]);
set(findall(gcf,'-property','FontName'),'FontName','Times New Roman');

box off
