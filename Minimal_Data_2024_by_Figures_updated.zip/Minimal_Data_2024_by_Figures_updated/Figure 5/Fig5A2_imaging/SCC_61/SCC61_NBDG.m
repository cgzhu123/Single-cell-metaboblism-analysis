clc;
clear all
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Load the first CSV file
data1 = readtable('SCC_61_IR-YC-.csv');

% Load the second CSV file
data2 = readtable('SCC_61_IR+YC-.csv');
% Load the third CSV file
data3 = readtable('SCC_61_IR+YC+.csv');

% Extract the third column values
thirdColumn1 = data1{:, 3};
thirdColumn2 = data2{:, 3};
thirdColumn3 = data3{:, 3};

% Display the third column values
disp('Third column values ');
disp(thirdColumn1);

disp('Third column values');
disp(thirdColumn2);

disp('Third column values');
disp(thirdColumn3);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Plot Kernel Density (Frequency Plot)
figure (1);
hold on;
[f1, xi1] = ksdensity(thirdColumn1 * 255);
plot(xi1, f1, 'LineWidth', 2, 'Color', 'k');
[f2, xi2] =  ksdensity(thirdColumn2 * 255);
plot(xi2, f2, 'LineWidth', 2, 'Color', 'r');
[f3, xi3] =  ksdensity(thirdColumn3 * 255);
plot(xi3, f3, 'LineWidth', 2, 'Color', 'g');
hold off;

% Set font properties for labels and title
xlabel('Intensity', 'FontName', 'Arial', 'FontSize', 24, 'Color', 'k');
ylabel('Probability Density', 'FontName', 'Arial', 'FontSize', 24, 'Color', 'k');
%title('SCC61_ 2-NBDG', 'FontName', 'Arial', 'FontSize', 18);
legend({'Control', 'RT', 'RT+YC-1'}, 'FontSize', 18, 'Location', 'northeast'); % Position the legend in the northeast corner


box on
yticks([ 0, 0.025,0.05]);
% xticks([0,100,200,300,400]);
% xlim([0 350]);

% Adjust figure as needed
set(gca, 'FontName', 'Arial', 'FontSize', 20, 'XColor', 'k', 'YColor', 'k'); % Customize axes font and color
set(gcf, 'Position', [0, 0, 550, 450]);
% Set the font to Times New Roman for all text objects in the figure
set(findall(gcf,'-property','FontName'),'FontName','Times New Roman');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% Combine data into a single vector and create a grouping variable
data_mean = [mean(thirdColumn1 * 255), mean(thirdColumn2 * 255),mean(thirdColumn3 * 255)];
sem_mean = [std(thirdColumn1 * 255) / sqrt(length(thirdColumn1 * 255)), ...
              std(thirdColumn2 * 255) / sqrt(length(thirdColumn2 * 255)),...
              std(thirdColumn3 * 255) / sqrt(length(thirdColumn3 * 255)),...
           ];





% Prepare data for ANOVA
group1 = thirdColumn1 * 255;
group2 = thirdColumn2 * 255;
group3 = thirdColumn3 * 255;


% Prepare data for ANOVA
allData = [group1; group2; group3];
groupLabels = [repmat({'Control'}, length(group1), 1); repmat({'RT'}, length(group2), 1); repmat({'RT+YC-1'}, length(group3), 1)];

% Perform ANOVA
[p, tbl, stats] = anova1(allData, groupLabels);

% Post-hoc test (Tukey's HSD)
[c, m, h, gnames] = multcompare(stats);

% Display p-values from post-hoc test
disp('P-values from post-hoc test:');
disp(c(:, [1 2 6])); % Display group comparison and p-value columns

% Create a new bar figure for means with error bars and p-values
figure;

% Calculate mean and SEM
data_mean = [mean(group1), mean(group2), mean(group3)];
sem_mean = [std(group1) / sqrt(length(group1)), std(group2) / sqrt(length(group2)), std(group3) / sqrt(length(group3))];

%Create a bar chart with error bars
bar(1, data_mean(1), 'FaceColor', 'k','FaceAlpha', 0.8,'BarWidth', 0.6);
hold on;
bar(2, data_mean(2), 'FaceColor', 'r','FaceAlpha', 0.8,'BarWidth', 0.6);
hold on;
bar(3, data_mean(3), 'FaceColor', 'g','FaceAlpha', 0.8,'BarWidth', 0.6);

errorbar(1, data_mean(1), sem_mean(1), 'k', 'linestyle', 'none', 'LineWidth', 1.5);
errorbar(2, data_mean(2), sem_mean(2), 'r', 'linestyle', 'none', 'LineWidth', 1.5);
errorbar(3, data_mean(3), sem_mean(3), 'g', 'linestyle', 'none', 'LineWidth', 1.5);


% % Add p-values to the plot
sigstar({[1, 2], [1, 3], [2, 3]}, c(:, 6));

% Change the size of the stars (*, **, ***)
markers = findall(gca, 'Type', 'text'); % Find all text objects
for i = 1:length(markers)
    if ismember(markers(i).String, {'*', '**', '***'})
        markers(i).FontSize = 24; % Change the font size to your desired value
    end
end


% Add p-values to the plot
for i = 1:size(c, 1)
    x = mean(c(i, 1:2));
    y = [400, 510, 440]; % Adjust these positions as needed
    text(x, y(i) + 5, sprintf('p=%.1e', c(i, 6)), 'FontSize', 20, 'FontWeight', 'normal', 'HorizontalAlignment', 'center');
end


% % Customize the plot
set(gca, 'XTick', 1:3, 'XTickLabel', {'Control', 'RT', 'RT+YC-1'}, 'FontName', 'Arial', 'FontSize', 18, 'XColor', 'k', 'YColor', 'k','XTickLabelRotation', 45);
ylabel('Intensity', 'FontName', 'Arial', 'FontSize', 26, 'Color', 'k');

yticks([ 20, 40,60]);
ylim([20 60]);

% Set the font to Times New Roman for all text objects in the figure
set(findall(gcf, '-property', 'FontName'), 'FontName', 'Times New Roman');
set(gcf, 'Position', [0, 0, 380, 350]);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Quantitative Analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Standard Deviation 
Std_devi = [std(thirdColumn1) , std(thirdColumn2) , std(thirdColumn3)];
Std_devi_percent = Std_devi*100;
fprintf('Normalized  Percent Standard Deviation %.2f%%\n', Std_devi_percent);

% Mean changes 
mean1 = mean(data_mean(1,1));
mean2 = mean(data_mean(1,2));
mean3 = mean(data_mean(1,3));
mean_change12 = ((mean2 - mean1) / mean1) * 100;
mean_change23 = ((mean3 - mean2) / mean2) * 100;
fprintf('Mean Change12: %.2f%%\n', mean_change12);
fprintf('Mean Change13: %.2f%%\n', mean_change23);

% Median changes 

median1 = median(thirdColumn1);
median2 = median(thirdColumn2);
median3 = median(thirdColumn3);
median_change12 = ((median2 - median1) / median1) * 100;
median_change23 = ((median3 - median2) / median2) * 100;
fprintf('Median Change12: %.2f%%\n', median_change12);
fprintf('Median Change13: %.2f%%\n', median_change23);


%Peak Location Change

[peak1, idx1] = max(f1);
peak_location1 = xi1(idx1);
[peak2, idx2] = max(f2);
peak_location2 = xi2(idx2);
[peak3, idx3] = max(f3);
peak_location3 = xi3(idx3);

 
% Percentage change in peak intensity
peak_change12 = ((peak_location2 - peak_location1) / peak_location1) * 100;
peak_change23 = ((peak_location3 - peak_location2) / peak_location2) * 100;

fprintf('Peak Location Chang12e: %.2f%%\n', peak_change12);
fprintf('Peak Location Chang23e: %.2f%%\n', peak_change23);

% FWHM intensity Changes

fwhm1 = computeFWHM(xi1, f1);
fwhm2 = computeFWHM(xi2, f2);
fwhm3 = computeFWHM(xi3, f3);

fwhm_change12 = ((fwhm2 - fwhm1) / fwhm1) * 100;
fwhm_change23 = ((fwhm3 - fwhm2) / fwhm2) * 100;

fprintf('FWHM Change12: %.2f%%\n', fwhm_change12);
fprintf('FWHM Change23: %.2f%%\n', fwhm_change23);


% Function to compute FWHM
function fwhm = computeFWHM(x, f)
    half_max = max(f) / 2;
    above_half_max = f >= half_max;
    edges = find(diff(above_half_max));
    if length(edges) == 2
        fwhm = x(edges(2)+1) - x(edges(1)); % Width at half max
    else
        fwhm = NaN; % Unable to calculate
    end
end


















































































