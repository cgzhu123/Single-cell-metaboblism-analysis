clc;
clear all;

data=[17	4.6
13.1	3.7
13.2	17.7
40.8	1.4
16.3	23
48.7	4
15.7	2.5
68.4	22.1
-32.3	3.4
75.1	-1.5
    ];

t=[1 2];

figure (1)
plot(t, data(1,:), 'b','MarkerSize',10,'Marker','x','LineWidth',1,'LineStyle','-');
hold on
plot(t, data(2,:), 'g','MarkerSize',10,'Marker','x','LineWidth',1,'LineStyle','-');
hold on
plot(t, data(3,:), 'b','MarkerSize',10,'Marker','pentagram','LineWidth',1,'LineStyle','-.');
hold on
plot(t, data(4,:), 'g','MarkerSize',10,'Marker','pentagram','LineWidth',1,'LineStyle','-.');
hold on
plot(t, data(5,:), 'b','MarkerSize',10,'Marker','diamond','LineWidth',1,'LineStyle',':');
hold on
plot(t, data(6,:), 'g','MarkerSize',10,'Marker','diamond','LineWidth',1,'LineStyle',':');
hold on
plot(t, data(7,:), 'b','MarkerSize',10,'Marker','square','LineWidth',1,'LineStyle','--');
hold on
plot(t, data(8,:), 'g','MarkerSize',10,'Marker','square','LineWidth',1,'LineStyle','--');
hold on
plot(t, data(9,:),'b','MarkerSize',10,'Marker','o','LineWidth',1,'LineStyle','-');
hold on
plot(t, data(10,:), 'g','MarkerSize',10,'Marker','o','LineWidth',1,'LineStyle','-');
hold on

axis([0.9,2.1,-40,100]);

title ('Histogram comparison','FontSize',20,'FontName','Times New Roman');
ylabel('Relative change (%)');

set(gca,'FontName','Times New Roman','FontSize',20,'XTick',[1 2],...
    'XTickLabel',{'Microscopy','Flowcytometry '},'YTick',...
    [-25 0 25 50 75 100]);
set(gcf, 'Position', [0, 0, 550, 450]);
set(findall(gcf,'-property','FontName'),'FontName','Times New Roman');

box off
