
% Load the the data file 
RSCC61TMREtreatIRYC = readtable('RSCC61_TMRE_treat IR&YC.xlsx');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



R2 = table2array(RSCC61TMREtreatIRYC(10:15,3));
R1 = table2array(RSCC61TMREtreatIRYC(7:9,3));
R0 = table2array(RSCC61TMREtreatIRYC(1:6,3));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % Combine data into a single vector and create a grouping variable
data_mean = [ mean(R0) mean(R1), mean(R2)];
sem_mean = [std(R0) / sqrt(length(R0)), ...
              std(R1) / sqrt(length(R1)),...
              std(R2) / sqrt(length(R2))];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)

% Prepare data for ANOVA



% Prepare data for ANOVA
allData = [R0; R1; R2];
groupLabels = [repmat({'Control'}, length(R0), 1); repmat({'RT'}, length(R1), 1); repmat({'RT+YC-1'}, length(R2), 1)];

% Perform ANOVA
[p, tbl, stats] = anova1(allData, groupLabels);

% Post-hoc test (Tukey's HSD)
[c, m, h, gnames] = multcompare(stats);

% Display p-values from post-hoc test
disp('P-values from post-hoc test:');
disp(c(:, [1 2 6])); % Display group comparison and p-value columns

% Create a new bar figure for means with error bars and p-values
figure;



%Create a bar chart with error bars
bar(1, data_mean(1), 'FaceColor', 'k','FaceAlpha', 0.8,'BarWidth', 0.6);
hold on;
bar(2, data_mean(2), 'FaceColor', 'r','FaceAlpha', 0.8,'BarWidth', 0.6);
hold on;
bar(3, data_mean(3), 'FaceColor', 'g','FaceAlpha', 0.8,'BarWidth', 0.6);

errorbar(1, data_mean(1), sem_mean(1), 'k', 'linestyle', 'none', 'LineWidth', 1.5);
errorbar(2, data_mean(2), sem_mean(2), 'r', 'linestyle', 'none', 'LineWidth', 1.5);
errorbar(3, data_mean(3), sem_mean(3), 'g', 'linestyle', 'none', 'LineWidth', 1.5);


% % Add p-values to the plot
sigstar({[1, 2], [1, 3], [2, 3]}, c(:, 6));

% Change the size of the stars (*, **, ***)
markers = findall(gca, 'Type', 'text'); % Find all text objects
for i = 1:length(markers)
    if ismember(markers(i).String, {'*', '**', '***'})
        markers(i).FontSize = 24; % Change the font size to your desired value
    end
end


% Add p-values to the plot
for i = 1:size(c, 1)
    x = mean(c(i, 1:2));
    y = [147, 176, 155]; % Adjust these positions as needed
    text(x, y(i) + 5, sprintf('p=%.1e', c(i, 6)), 'FontSize', 20, 'FontWeight', 'normal', 'HorizontalAlignment', 'center');
end


% % Customize the plot
set(gca, 'XTick', 1:3, 'XTickLabel', {'Control', 'RT', 'RT+YC-1'}, 'FontName', 'Arial', 'FontSize', 18, 'XColor', 'k', 'YColor', 'k','XTickLabelRotation', 45);
ylabel('Intensity', 'FontName', 'Arial', 'FontSize', 26, 'Color', 'k');

%yticks([ 80, 130,180]);
ylim([15000 30000]);


% Set the font to Times New Roman for all text objects in the figure
set(findall(gcf, '-property', 'FontName'), 'FontName', 'Times New Roman');
set(gcf, 'Position', [0, 0, 380, 350]);


% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Quantitative Analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Standard Deviation 
Std_devi = [std(R0/(max(R0))), std(R1/(max(R1))) , std(R2/(max(R2))) ];
Std_devi_percent = Std_devi*100;
fprintf('Normalized  Percent Standard Deviation %.2f%%\n', Std_devi_percent);

% Mean changes 
mean1 = mean(R0);
mean2 = mean(R1);
mean3 = mean(R2);
mean_change12 = ((mean2 - mean1) / mean1) * 100;
mean_change23 = ((mean3 - mean2) / mean2) * 100;
fprintf('Mean Change12: %.2f%%\n', mean_change12);
fprintf('Mean Change23: %.2f%%\n', mean_change23);