clc;
clear all
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Load the first CSV file
data1 = readtable('SCC_61_IR-YC-.csv');

% Load the second CSV file
data2 = readtable('SCC_61_IR+YC-.csv');
% Load the third CSV file
data3 = readtable('SCC_61_IR+YC+.csv');

% Extract the third column values
thirdColumn1 = data1{:, 3};
thirdColumn2 = data2{:, 3};
thirdColumn3 = data3{:, 3};

% Display the third column values
disp('Third column values ');
disp(thirdColumn1);

disp('Third column values');
disp(thirdColumn2);

disp('Third column values');
disp(thirdColumn3);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Plot Kernel Density (Frequency Plot)
figure (1);
hold on;
[f1, xi1] = ksdensity(thirdColumn1 * 255);
plot(xi1, f1, 'LineWidth', 2, 'Color', 'k');
[f2, xi2] =  ksdensity(thirdColumn2 * 255);
plot(xi2, f2, 'LineWidth', 2, 'Color', 'r');
[f3, xi3] =  ksdensity(thirdColumn3 * 255);
plot(xi3, f3, 'LineWidth', 2, 'Color', 'g');
hold off;

% Set font properties for labels and title
xlabel('Intensity', 'FontName', 'Arial', 'FontSize', 24, 'Color', 'k');
ylabel('Frequency', 'FontName', 'Arial', 'FontSize', 24, 'Color', 'k');
%title('SCC61_ 2-NBDG', 'FontName', 'Arial', 'FontSize', 18);
legend({'Control', 'RT', 'RT+YC-1'}, 'FontSize', 18, 'Location', 'northeast'); % Position the legend in the northeast corner


box on
yticks([ 0, 0.025,0.05]);
% xticks([0,100,200,300,400]);
% xlim([0 350]);

% Adjust figure as needed
set(gca, 'FontName', 'Arial', 'FontSize', 20, 'XColor', 'k', 'YColor', 'k'); % Customize axes font and color
set(gcf, 'Position', [0, 0, 550, 450]);
% Set the font to Times New Roman for all text objects in the figure
set(findall(gcf,'-property','FontName'),'FontName','Times New Roman');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% Combine data into a single vector and create a grouping variable
data_mean = [mean(thirdColumn1 * 255), mean(thirdColumn2 * 255),mean(thirdColumn3 * 255)];
sem_mean = [std(thirdColumn1 * 255) / sqrt(length(thirdColumn1 * 255)), ...
              std(thirdColumn2 * 255) / sqrt(length(thirdColumn2 * 255)),...
              std(thirdColumn3 * 255) / sqrt(length(thirdColumn3 * 255)),...
           ];





% Prepare data for ANOVA
group1 = thirdColumn1 * 255;
group2 = thirdColumn2 * 255;
group3 = thirdColumn3 * 255;


% Prepare data for ANOVA
allData = [group1; group2; group3];
groupLabels = [repmat({'Control'}, length(group1), 1); repmat({'RT'}, length(group2), 1); repmat({'RT+YC-1'}, length(group3), 1)];

% Perform ANOVA
[p, tbl, stats] = anova1(allData, groupLabels);

% Post-hoc test (Tukey's HSD)
[c, m, h, gnames] = multcompare(stats);

% Display p-values from post-hoc test
disp('P-values from post-hoc test:');
disp(c(:, [1 2 6])); % Display group comparison and p-value columns

% Create a new bar figure for means with error bars and p-values
figure;

% Calculate mean and SEM
data_mean = [mean(group1), mean(group2), mean(group3)];
sem_mean = [std(group1) / sqrt(length(group1)), std(group2) / sqrt(length(group2)), std(group3) / sqrt(length(group3))];

%Create a bar chart with error bars
bar(1, data_mean(1), 'FaceColor', 'k','FaceAlpha', 0.8,'BarWidth', 0.6);
hold on;
bar(2, data_mean(2), 'FaceColor', 'r','FaceAlpha', 0.8,'BarWidth', 0.6);
hold on;
bar(3, data_mean(3), 'FaceColor', 'g','FaceAlpha', 0.8,'BarWidth', 0.6);

errorbar(1, data_mean(1), sem_mean(1), 'k', 'linestyle', 'none', 'LineWidth', 1.5);
errorbar(2, data_mean(2), sem_mean(2), 'r', 'linestyle', 'none', 'LineWidth', 1.5);
errorbar(3, data_mean(3), sem_mean(3), 'g', 'linestyle', 'none', 'LineWidth', 1.5);


% % Add p-values to the plot
sigstar({[1, 2], [1, 3], [2, 3]}, c(:, 6));

% Change the size of the stars (*, **, ***)
markers = findall(gca, 'Type', 'text'); % Find all text objects
for i = 1:length(markers)
    if ismember(markers(i).String, {'*', '**', '***'})
        markers(i).FontSize = 24; % Change the font size to your desired value
    end
end


% Add p-values to the plot
for i = 1:size(c, 1)
    x = mean(c(i, 1:2));
    y = [400, 510, 440]; % Adjust these positions as needed
    text(x, y(i) + 5, sprintf('p=%.1e', c(i, 6)), 'FontSize', 18, 'FontWeight', 'normal', 'HorizontalAlignment', 'center');
end


% % Customize the plot
set(gca, 'XTick', 1:3, 'XTickLabel', {'Control', 'RT', 'RT+YC-1'}, 'FontName', 'Arial', 'FontSize', 18, 'XColor', 'k', 'YColor', 'k','XTickLabelRotation', 45);
ylabel('Intensity', 'FontName', 'Arial', 'FontSize', 26, 'Color', 'k');

yticks([ 20, 40,60]);
ylim([20 60]);

% Set the font to Times New Roman for all text objects in the figure
set(findall(gcf, '-property', 'FontName'), 'FontName', 'Times New Roman');
set(gcf, 'Position', [0, 0, 380, 350]);





















































































% clc;
% clear all
% close all
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Set the directories where your Excel files are located
% directory1 = 'C:\Users\psa258\OneDrive - University of Kentucky\Documents\Manuscript\Jing Microscopy Images-Cell Profiler Processed\20230909-NBDG-SCC61- treat IR(4Gy) & YC-1(50uM, when doing IR)-seeding 2d+1d after IR\Second Repeat\IR- YC-\Data';
% directory2 = 'C:\Users\psa258\OneDrive - University of Kentucky\Documents\Manuscript\Jing Microscopy Images-Cell Profiler Processed\20230909-NBDG-SCC61- treat IR(4Gy) & YC-1(50uM, when doing IR)-seeding 2d+1d after IR\Second repeat\IR+ YC-\Data';
% directory3 = 'C:\Users\psa258\OneDrive - University of Kentucky\Documents\Manuscript\Jing Microscopy Images-Cell Profiler Processed\20230909-NBDG-SCC61- treat IR(4Gy) & YC-1(50uM, when doing IR)-seeding 2d+1d after IR\Second repeat\IR+ YC+\Data';
% 
% % Get a list of all Excel files in the specified directories
% files1 = dir(fullfile(directory1, 'NBDG_*EditedObjects.csv'));
% files2 = dir(fullfile(directory2, 'NBDG_*EditedObjects.csv'));
% files3 = dir(fullfile(directory3, 'NBDG_*EditedObjects.csv'));
% files4 = dir(fullfile(directory4, 'NBDG_*EditedObjects.csv'));
% 
% % Initialize cell arrays to store the loaded data
% excelData1 = cell(10, 1);
% excelData2 = cell(10, 1);
% excelData3 = cell(10, 1);
% excelData4 = cell(10, 1);
% 
% % Initialize cell arrays to store the 11th column values for each file
% column11Values1 = cell(10, 1);
% column11Values2 = cell(10, 1);
% column11Values3 = cell(10, 1);
% column11Values4 = cell(10, 1);
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Loop through each Excel file in directory 1
% for i = 1:min(10, numel(files1)) % Load up to 10 files
%     % Construct the full file path
%     filePath = fullfile(directory1, files1(i).name);
% 
%     % Read the Excel file
%     try
%         excelData1{i} = readmatrix(filePath); % Use readmatrix for newer MATLAB versions
%     % catch
%     %     % If readmatrix fails, try using xlsread for older versions
%     %     raw = xlsread(filePath);
%     %     excelData1{i} = cell2mat(raw);
%      end
% 
%     % Extract the 11th column values
%     column11Values1{i} = excelData1{i}(:, 11);
% end
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Loop through each Excel file in directory 2
% for i = 1:min(10, numel(files2)) % Load up to 10 files
%     % Construct the full file path
%     filePath = fullfile(directory2, files2(i).name);
% 
%     % Read the Excel file
%     try
%         excelData2{i} = readmatrix(filePath); % Use readmatrix for newer MATLAB versions
%     % catch
%     %     % If readmatrix fails, try using xlsread for older versions
%     %     raw = xlsread(filePath);
%     %     excelData2{i} = cell2mat(raw);
%      end
% 
%     % Extract the 11th column values
%     column11Values2{i} = excelData2{i}(:, 11);
% end
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Loop through each Excel file in directory 3
% for i = 1:min(10, numel(files3)) % Load up to 10 files
%     % Construct the full file path
%     filePath = fullfile(directory3, files3(i).name);
% 
%     % Read the Excel file
%     try
%         excelData3{i} = readmatrix(filePath); % Use readmatrix for newer MATLAB versions
%     % catch
%     %     % If readmatrix fails, try using xlsread for older versions
%     %     raw = xlsread(filePath);
%     %     excelData1{i} = cell2mat(raw);
%      end
% 
%     % Extract the 11th column values
%     column11Values3{i} = excelData3{i}(:, 11);
% end
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Loop through each Excel file in directory 4
% for i = 1:min(10, numel(files4)) % Load up to 10 files
%     % Construct the full file path
%     filePath = fullfile(directory4, files4(i).name);
% 
%     % Read the Excel file
%     try
%         excelData4{i} = readmatrix(filePath); % Use readmatrix for newer MATLAB versions
%     % catch
%     %     % If readmatrix fails, try using xlsread for older versions
%     %     raw = xlsread(filePath);
%     %     excelData1{i} = cell2mat(raw);
%      end
% 
%     % Extract the 11th column values
%     column11Values4{i} = excelData4{i}(:, 11);
% end
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Display or further process the loaded data and 11th column values as needed
% disp('Loaded Excel Data - Directory 1:');
% disp(excelData1);
% 
% % Assuming column11Values has been loaded and contains valid data
% disp('11th Column Values - Directory 1:');
% disp(column11Values1);
% 
% % Display or further process the loaded data and 11th column values for directory 2
% disp('Loaded Excel Data - Directory 2:');
% disp(excelData2);
% 
% % Assuming column11Values has been loaded and contains valid data
% disp('11th Column Values - Directory 2:');
% disp(column11Values2);
% 
% 
% % Display or further process the loaded data and 11th column values for directory 3
% disp('Loaded Excel Data - Directory 3:');
% disp(excelData3);
% 
% % Assuming column11Values has been loaded and contains valid data
% disp('11th Column Values - Directory 3:');
% disp(column11Values3);
% 
% 
% % Display or further process the loaded data and 11th column values for directory 4
% disp('Loaded Excel Data - Directory 4:');
% disp(excelData4);
% 
% % Assuming column11Values has been loaded and contains valid data
% disp('11th Column Values - Directory 4:');
% disp(column11Values4);
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% % Plot Kernel Density (Frequency Plot)
% figure (1);
% hold on;
% [f1, xi1] = ksdensity(cell2mat(column11Values1) * 255);
% plot(xi1, f1, 'LineWidth', 2, 'Color', 'k');
% [f2, xi2] =  ksdensity(cell2mat(column11Values2) * 255);
% plot(xi2, f2, 'LineWidth', 2, 'Color', 'r');
% [f3, xi3] =  ksdensity(cell2mat(column11Values3) * 255);
% plot(xi3, f3, 'LineWidth', 2, 'Color', 'g');
% [f4, xi4] =  ksdensity(cell2mat(column11Values4) * 255);
% plot(xi4, f4, 'LineWidth', 2, 'Color', 'b');
% hold off;
% 
% % Set font properties for labels and title
% xlabel('Intensity', 'FontName', 'Arial', 'FontSize', 24, 'Color', 'k');
% ylabel('Frequency', 'FontName', 'Arial', 'FontSize', 24, 'Color', 'k');
% %title('SCC61_ 2-NBDG', 'FontName', 'Arial', 'FontSize', 18);
% legend({'YC-1', 'YC+1', 'RT+YC-1', 'RT+YC+1'}, 'FontSize', 18, 'Location', 'northeast'); % Position the legend in the northeast corner
% 
% box on
% yticks([ 0, 0.025,0.05]);
% % xticks([0,100,200,300,400]);
% % xlim([0 350]);
% 
% % Adjust figure as needed
% set(gca, 'FontName', 'Arial', 'FontSize', 20, 'XColor', 'k', 'YColor', 'k'); % Customize axes font and color
% set(gcf, 'Position', [0, 0, 550, 450]);
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% % Create a figure
% figure (2);
% 
% 
% % Plot the histogram with a kernel density estimate
% h1 = histfit(cell2mat(column11Values1) * 255, 20, 'kernel');
% 
% % Customize the histogram bins 
% h1(1).FaceColor = [.7 .7 .7]; % Example color
% % Customize the fit line (the second handle in h)
% h1(2).Color = 'k'; % Black color for the fit line
% h1(2).LineWidth = 2; % Line width of 2
% 
% hold on
% 
% % Plot the histogram with a kernel density estimate
% h2 = histfit(cell2mat(column11Values2) * 255, 20, 'kernel');
% 
% % Customize the histogram bins
% h2(1).FaceColor = [.9 .6 .3]; % Example color
% % Customize the fit line (the second handle in h)
% h2(2).Color = 'r'; % Red color for the fit line
% h2(2).LineWidth = 2; % Line width of 2
% 
% hold on
% 
% % Plot the histogram with a kernel density estimate
% h3 = histfit(cell2mat(column11Values3) * 255, 20, 'kernel');
% 
% % Customize the histogram bins 
% h3(1).FaceColor = [.5 .7 .9]; % Example color
% % Customize the fit line (the second handle in h)
% h3(2).Color = 'g'; % Black color for the fit line
% h3(2).LineWidth = 2; % Line width of 2
% 
% hold on
% 
% % Plot the histogram with a kernel density estimate
% h4 = histfit(cell2mat(column11Values4) * 255, 20, 'kernel');
% 
% % Customize the histogram bins 
% h4(1).FaceColor = [.3 .3 .9]; % Example color
% % Customize the fit line (the second handle in h)
% h4(2).Color = 'b'; % Black color for the fit li
% h4(2).LineWidth = 2; % Line width of 2
% 
% 
% 
% % Set font properties for labels and title
% xlabel('Intensity', 'FontName', 'Arial', 'FontSize', 24, 'Color', 'k');
% ylabel('Cell Count', 'FontName', 'Arial', 'FontSize', 24, 'Color', 'k');
% %title('SCC61_ 2-NBDG', 'FontName', 'Arial', 'FontSize', 18);
% legend([h1(2), h2(2), h3(2), h4(2)],{'YC-1', 'YC+1', 'RT+YC-1', 'RT+YC+1'}, 'FontSize', 18, 'Location', 'northeast'); % Position the legend in the northeast corner
% 
% 
% % box on
% yticks([ 0, 75,150]);
% % %xticks([0,40,80,120]);
% 
% % Adjust figure as needed
% set(gca, 'FontName', 'Arial', 'FontSize', 20, 'XColor', 'k', 'YColor', 'k'); % Customize axes font and color
% set(gcf, 'Position', [0, 0, 550, 450]);
% 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% % Combine data into a single vector and create a grouping variable
% data_mean = [mean((cell2mat(column11Values1) * 255)), mean((cell2mat(column11Values2) * 255)),mean((cell2mat(column11Values3) * 255)),mean((cell2mat(column11Values4) * 255))];
% sem_mean = [std((cell2mat(column11Values1) * 255)) / sqrt(length((cell2mat(column11Values1) * 255))), ...
%               std((cell2mat(column11Values2) * 255)) / sqrt(length((cell2mat(column11Values2) * 255))),...
%               std((cell2mat(column11Values3) * 255)) / sqrt(length((cell2mat(column11Values3) * 255))),...
%               std((cell2mat(column11Values4) * 255)) / sqrt(length((cell2mat(column11Values4) * 255)))];
% 
% 
% 
% 
% 
% % Prepare data for ANOVA
% group1 = cell2mat(column11Values1) * 255;
% group2 = cell2mat(column11Values2) * 255;
% group3 = cell2mat(column11Values3) * 255;
% group4 = cell2mat(column11Values4) * 255;
% 
% % Combine all groups into a single vector and create a grouping variable
% allData = [group1; group2; group3; group4];
% groupLabels = [repmat({'Group 1'}, length(group1), 1); repmat({'Group 2'}, length(group2), 1); repmat({'Group 3'}, length(group3), 1); repmat({'Group 4'}, length(group4), 1)];
% 
% % Perform one-way ANOVA
% [p, tbl, stats] = anova1(allData, groupLabels);
% 
% % Display the results
% disp('One-way ANOVA results:');
% disp(['p-value: ', num2str(p)]);
% disp('ANOVA table:');
% disp(tbl);
% 
% % Post-hoc analysis (if significant)
% if p < 0.05
%     disp('Performing post-hoc analysis...');
%     results = multcompare(stats);
%     disp('Post-hoc comparison results:');
%     disp(results);
% end
% 
% figure(5)
% 
% %Create a bar chart with error bars
% bar(1, data_mean(1), 'FaceColor', 'k','FaceAlpha', 0.8,'BarWidth', 0.6);
% hold on;
% bar(2, data_mean(2), 'FaceColor', 'r','FaceAlpha', 0.8,'BarWidth', 0.6);
% hold on;
% bar(3, data_mean(3), 'FaceColor', 'g','FaceAlpha', 0.8,'BarWidth', 0.6);
% hold on;
% bar(4, data_mean(4), 'FaceColor', 'b','FaceAlpha', 0.8,'BarWidth', 0.6);
% errorbar(1, data_mean(1), sem_mean(1), 'k', 'linestyle', 'none', 'LineWidth', 1.5);
% errorbar(2, data_mean(2), sem_mean(2), 'r', 'linestyle', 'none', 'LineWidth', 1.5);
% errorbar(3, data_mean(3), sem_mean(3), 'g', 'linestyle', 'none', 'LineWidth', 1.5);
% errorbar(4, data_mean(4), sem_mean(4), 'b', 'linestyle', 'none', 'LineWidth', 1.5);
% 
% 
% % Customize the plot
% set(gca, 'XTick', 1:4, 'XTickLabel', {'YC-1', 'YC+1', 'RT+YC-1', 'RT+YC+1'}, 'FontName', 'Arial', 'FontSize', 18, 'XColor', 'k', 'YColor', 'k','XTickLabelRotation', 45);
% ylabel('Intensity', 'FontName', 'Arial', 'FontSize', 22, 'Color', 'k');
% 
% yticks([ 10, 30,50]);
% ylim([10 55]);
% 
% 
% % Display ANOVA results in the plot
% if p < 0.05
%     significanceText = sprintf('p= %.1e', p);
% else
%     significanceText = sprintf('p= %.1e (n.s.)', p);
% end
% 
% text(2.5, max(data_mean + sem_mean) * 1.1, significanceText, 'HorizontalAlignment', 'center', 'FontSize', 15, 'Color', 'k');
% set(gcf, 'Position', [0, 0, 380, 350]);
% hold off;
% 
% 
% 
% 
% 
% 
% 
